//index.js
const app = getApp()
var a=0
var b=0
var c=0
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:"",
    num:"",
    userinfo:{},
    openid:"",
    photoPath:"",
    Wnob:"",
    Break:"",
    good:36,
    rank:"",
  },
  onGotUserInfo:function(e){
    
  },
  onLoad:function(options){
    var showDialog = getApp().globalData.showDialog
    this.setData({
      id:showDialog._id
    })
    const db = wx.cloud.database({
      env:'cloud-rh0km'
    })
    db.collection('HafetyHelmet').where({
      _id:this.data.id
    }).get({
      success:res =>{
        console.log(res)
        this.setData({
          Wnob:res.data[0].WnobTime,
          Break:res.data[0].WnumberOfBreak,
          rank:res.data[0].rank,
        })
      }
    })
  },
  sendMsg:function(e){
    wx.request({
    url: 'https://cff.mynatapp.cc/wxXcx/sendMessage',
    method: 'POST',
    data: { },
    header: {
    'content-type': 'application/json' // 默认值
    },
    success(res) {
    console.log(res)
    }
    })
    },
    requestMsg(){
      return new Promise((resolve, reject) => {
      wx.requestSubscribeMessage({
      tmplIds: ["foMf4bZ6eaHCWFN5pLV5oR9YfxQOQMIL9flGp360RAw"],
      success: (res) => {
       if (res['foMf4bZ6eaHCWFN5pLV5oR9YfxQOQMIL9flGp360RAw'] === 'accept'){
        wx.showToast({
        title: '订阅OK！',
        duration: 1000,
        success(data) {
        //成功
          resolve()
        }
       })
       }
      },
      fail(err) {
       //失败
       console.error(err);
       reject()
      }
    })
    })
  },
  sendMsg:function(e){
    wx.request({
    url: 'https://cff.mynatapp.cc/wxXcx/sendMessage',
    method: 'POST',
    data: { },
    header: {
    'content-type': 'application/json' // 默认值
    },
    success(res) {
    console.log(res)
    }
    })
    },
   
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})