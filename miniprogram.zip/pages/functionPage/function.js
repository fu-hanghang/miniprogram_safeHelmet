// pages/index2/index2.js
Page({
  //订阅消息
  requestMsg(){
    return new Promise((resolve, reject) => {
    wx.requestSubscribeMessage({
    tmplIds: ["0HJRkAGfIEU2DARNpQK2pcUCu7Gw2ccQQu8NRVXP7Sc"],
    success:function (res) {
     if (res['0HJRkAGfIEU2DARNpQK2pcUCu7Gw2ccQQu8NRVXP7Sc'] === 'accept'){
     wx.showToast({
     title: '订阅成功！',
     duration: 1000,
     success(data) {
     //成功
     resolve()
     }
     })
     }
    },
    fail(err) {
     //失败
     console.error(err);
     reject()
    }
    })
    })
    } ,
   
  /**
   * 页面的初始数据
   */
  data: {

  },
  
   
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})