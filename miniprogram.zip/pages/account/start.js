const app = getApp()

const db = wx.cloud.database({
  env:'cloud-rh0km'
})
Page({
  data: {
    id: '',
    password: '',
    success: false,
    text: '',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  bindViewTap: function() {
    wx.navigateTo({
      url: '../login/register'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  // 获取输入账号 
  phoneInput: function (e) {
    this.setData({
      id: e.detail.value
    })
  },
 /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 获取输入密码 
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },
  // 登录 
  login: function () {
    var that = this;   
    var warn = null; //warn为当手机号为空或格式不正确时提示用户的文字，默认为空
    if (that.data.id.length == 0) {
      wx.showToast({
        title: '用户名不能为空',
        icon: 'loading',
        duration: 1000
      })
    } else if (that.data.password.length == 0) {
      wx.showToast({
        title: '密码不能为空',
        icon: 'loading',
        duration: 1000
      })
    }else {
      db.collection('User').where({
          _id:that.data.id
      }).get({
        success:res =>{
          // console.log(that.data.password)
          if(that.data.password==res.data[0].passwords) {
            warn = "登陆成功";
            wx.showModal({
              title: '提示',
              content: warn
            })
            getApp().globalData.showDialog = res.data[0];
            wx.switchTab({
              url: '../index/index',
            })
          }else{
            warn = "账号或密码错误";
            wx.showModal({
              title: '提示',
              content: warn
            })
            return;
          }
        }
      })
    }
  },
  // 注册 
  register: function () {
    wx.navigateTo({
      url: 'login/register',
    })
  },
  
})
