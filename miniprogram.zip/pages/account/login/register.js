// pages/zhuce/zhuce.js
const db = wx.cloud.database({
  env:'cloud-rh0km'
})
const admin = db.collection('User');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    id:"",
    password:"",
  },
  zhuce: function (res) {
    let flag=false
    console.log(res.detail.value)
    admin.get({
      success:(r)=>{
        let admins = r.data;//获取到的对象数组数据
        for (let i = 0; i < admins.length; i++) {  //遍历数据库对象集合
          if (res.detail.value.username === admins[i]._id) { //用户名存在
            flag = true;
              break;
          }
        }
        if (flag === true) {    //已注册
          wx.showToast({
            title: '账号已注册！',
            icon: 'success',
            duration: 2500
          })
        } else {  //未注册
          if (res.detail.value.username=="") {
            wx.showToast({
              title: "工号不能为空",
              icon: 'none',
              duration: 2000
            })
          }
          if (res.detail.value.password1==""||res.detail.value.password2=="") {
              wx.showToast({
                title: "密码不能为空",
                icon: 'none',
                duration: 2000
              })
          }
          if (res.detail.value.password1!=res.detail.value.password2) {
              wx.showToast({
                title: "前后密码不一致",
                icon: 'none',
                duration: 2000
              })
            }
          admin.add({  //添加数据
            data: {
              _id:res.detail.value.username,
              passwords:res.detail.value.password1
            }
          }).then(e => {
            console.log('注册成功！')
            wx.showToast({
              title: '注册成功！',
              icon: 'success',
              duration: 3000
            })
            wx.redirectTo({
              url: '../start',
            })
          })
        }
      }
    }) 
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
})
