// pages/account/account.js
    const db = wx.cloud.database({
      env:'cloud-rh0km'
    })
Page({
  /**
   * 页面的初始数据
   */
  data: {
    id:"",
    userinfo:{},
    name:"",
    num:"",
    openid:"",
    photoPath:"",
    numberOfBreak:""
  },
  onGotUserInfo:function(e){
    
  },
  onLoad:function(options){
    var showDialog = getApp().globalData.showDialog
    console.log(showDialog)
    this.setData({
      id:showDialog._id
    })
    console.log(showDialog._id)
    db.collection('HafetyHelmet').where({
      _id:this.data.id
    }).get({
      success:res =>{
        console.log(res)
        console.log(res.data[0])
        this.setData({
          name:res.data[0].Wname,
          num:res.data[0].Wnum,
          photoPath:res.data[0].Wimgpath,
          numberOfBreak:res.data[0].WnumberOfBreak
        })
      }
    })
    
  },
out: function () {
  wx.navigateTo({
    url: '../start',
  })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})